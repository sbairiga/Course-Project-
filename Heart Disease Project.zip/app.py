
import pickle                                      #importing the pickle library library and streamlit library 
import streamlit as st

import time                                    #importing time library , to use time function to add spinner features 

with st.spinner('Connecting to MedPlus ...'):
    time.sleep(1)

st.title("MedPlus")


pickle_in = open('classifier', 'rb')                       #we are using the classifier which is load in pickle 
classifier = pickle.load(pickle_in)

@st.cache()                                             #when the function is called ,it stores the value and stores in local cache

#Define the function which will make the prediction using data
#inputs from users to enter age,sex and other values to predict 
def prediction(age,sex,non_anginal_pain,max_heart_rate,exercise_induced_angina):
    
    # Make predictions
    prediction = classifier.predict(
        [[age,sex,non_anginal_pain,max_heart_rate,exercise_induced_angina]])
    
    if prediction == 0:
        pred = 'You are doing Good!! You dont have heart disease,Take Care'  #if preditcion is 0 from model then user dont have any disease
    else:
        pred = 'You are risk of having heart disease , Please consult doctor' #if prediction is 1 from model , then user has risk of heart disease
    return pred

# This is the main function in which we define our webpage
#we have define the max ,min value allowed to be entered by user 
#We have also defined the value populated in webpage and value step for incremental 
def main():
    
    # Create input fields
    age = st.number_input("Enter Age :",
                                  min_value=0,             
                                  max_value=120,
                                  value=0,
                                  step=1,
                                 )
    sex = st.number_input("Enter Sex :",
                              min_value=0,
                              max_value=1,
                              value=0,
                              step=1
                             )

    non_anginal_pain = st.number_input("Non Anginal value ? ",
                              min_value=0,
                              max_value=1,
                              value=0,
                              step=1
                             )
    max_heart_rate = st.number_input("Maximum heart rate recorded",
                          min_value=0,
                          max_value=180,
                          value=0,
                          step=1
                         )
    exercise_induced_angina = st.number_input("Induced Angina value?",
                          min_value=0,
                          max_value=1,
                          value=0,
                          step=1
                         )

    result = ""
    
    # When 'Predict' is clicked, make the prediction and store it
    if st.button("Predict"):
        result = prediction(age,sex,non_anginal_pain,max_heart_rate,exercise_induced_angina)
        st.success(result)
        
if __name__=='__main__':
    main()
    
